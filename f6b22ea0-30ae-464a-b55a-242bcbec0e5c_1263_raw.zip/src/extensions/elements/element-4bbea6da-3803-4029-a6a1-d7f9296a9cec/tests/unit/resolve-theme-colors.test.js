import { describe, it, expect, afterEach } from 'vitest';
import { resolveThemeColors } from '../../src/lib/resolveThemeColors.js';

const root = document.documentElement;

afterEach(() => {
    root.style.removeProperty('--color-primary');
    root.style.removeProperty('--color-accent');
});

describe('resolveThemeColors', () => {
    it('passes concrete colors and non-color strings through unchanged', () => {
        expect(resolveThemeColors('#3b82f6', root)).toBe('#3b82f6');
        expect(resolveThemeColors('rgba(59,130,246,0.6)', root)).toBe('rgba(59,130,246,0.6)');
        expect(resolveThemeColors('Sales', root)).toBe('Sales');
    });

    it('passes primitives and functions through unchanged', () => {
        const fn = (ctx) => ctx.dataIndex;
        expect(resolveThemeColors(42, root)).toBe(42);
        expect(resolveThemeColors(true, root)).toBe(true);
        expect(resolveThemeColors(null, root)).toBe(null);
        expect(resolveThemeColors(fn, root)).toBe(fn);
    });

    it('resolves a var(--...) token to the current computed CSS value', () => {
        root.style.setProperty('--color-primary', '#112233');
        expect(resolveThemeColors('var(--color-primary,#000000)', root)).toBe('#112233');
    });

    it('re-resolves the same token to a new value when the theme (CSS var) changes', () => {
        root.style.setProperty('--color-primary', '#aaaaaa');
        expect(resolveThemeColors('var(--color-primary,#000000)', root)).toBe('#aaaaaa');
        root.style.setProperty('--color-primary', '#bbbbbb');
        expect(resolveThemeColors('var(--color-primary,#000000)', root)).toBe('#bbbbbb');
    });

    it('falls back to the embedded fallback when the CSS var is not set', () => {
        expect(resolveThemeColors('var(--color-unknown,#abcdef)', root)).toBe('#abcdef');
    });

    it('returns the raw token when neither the CSS var nor a fallback resolve', () => {
        expect(resolveThemeColors('var(--color-unknown)', root)).toBe('var(--color-unknown)');
    });

    it('resolves tokens deep inside a chart data structure and preserves the rest', () => {
        root.style.setProperty('--color-primary', '#123456');
        root.style.setProperty('--color-accent', '#654321');
        const input = {
            labels: ['Jan', 'Feb'],
            datasets: [
                {
                    label: 'Sales',
                    data: [1, 2],
                    backgroundColor: 'var(--color-primary,#3b82f6)',
                    borderColor: ['#ff0000', 'var(--color-accent,#00ff00)'],
                },
            ],
        };
        const out = resolveThemeColors(input, root);
        expect(out.datasets[0].backgroundColor).toBe('#123456');
        expect(out.datasets[0].borderColor).toEqual(['#ff0000', '#654321']);
        expect(out.labels).toEqual(['Jan', 'Feb']);
        expect(out.datasets[0].data).toEqual([1, 2]);
    });

    it('preserves scriptable function options', () => {
        const colorFn = (ctx) => `hsl(${ctx.dataIndex}deg,50%,50%)`;
        const out = resolveThemeColors({ borderColor: colorFn }, root);
        expect(out.borderColor).toBe(colorFn);
    });

    it('resolves tokens in options-level colors (scales, legend, datalabels, annotations)', () => {
        root.style.setProperty('--color-primary', '#0f172a');
        const options = {
            scales: {
                y: {
                    ticks: { color: 'var(--color-primary,#000000)' },
                    grid: { color: 'var(--color-unknown,#e5e7eb)' },
                },
            },
            plugins: {
                legend: { labels: { color: 'var(--color-primary,#000000)' } },
                datalabels: { color: 'var(--color-primary,#000000)' },
                annotation: { annotations: { line1: { borderColor: 'var(--color-primary,#000000)' } } },
            },
        };
        const out = resolveThemeColors(options, root);
        expect(out.scales.y.ticks.color).toBe('#0f172a');
        expect(out.scales.y.grid.color).toBe('#e5e7eb');
        expect(out.plugins.legend.labels.color).toBe('#0f172a');
        expect(out.plugins.datalabels.color).toBe('#0f172a');
        expect(out.plugins.annotation.annotations.line1.borderColor).toBe('#0f172a');
    });

    it('resolves per-slice color arrays used by pie/doughnut/polarArea datasets', () => {
        root.style.setProperty('--color-primary', '#111111');
        root.style.setProperty('--color-accent', '#222222');
        const out = resolveThemeColors(
            {
                datasets: [
                    { backgroundColor: ['var(--color-primary,#000000)', 'var(--color-accent,#000000)', '#333333'] },
                ],
            },
            root
        );
        expect(out.datasets[0].backgroundColor).toEqual(['#111111', '#222222', '#333333']);
    });
});
