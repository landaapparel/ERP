import { createMemoryHistory, createRouter, createWebHistory } from 'vue-router';

import wwPage from './views/wwPage.vue';

import {
    initializeData,
    initializePlugins,
    initializeIntegrationInstances,
    onPageUnload,
} from '@/_common/helpers/data';
import { convertPathToRouterFormat } from '@/_common/helpers/urlParametersParsing';
import { getRuntimeEnvironment } from '@/helpers/frontEnv.js';
import { useBackAuthStore } from '@/pinia/backAuth.js';
/* wwFront:start */
import { isStaticRenderingActive } from '@/_front/rendering/staticRenderingContext';
/* wwFront:end */

/**
 * @typedef {import('vue-router').Router} Router
 * @typedef {import('vue-router').RouteRecordRaw} RouteRecordRaw
 * @typedef {import('vue-router').RouterOptions} RouterOptions
 * @typedef {import('vue-router').RouterScrollBehavior} RouterScrollBehavior
 */

/**
 * @typedef {Object} Lang
 * @property {string} lang
 * @property {boolean} [default]
 * @property {boolean} [isDefaultPath]
 */

/**
 * @typedef {Object} PageSecurity
 * @property {'authenticated' | string} [accessRule]
 * @property {string[]} [accessRoles]
 * @property {'AND' | 'OR'} [accessRolesCondition]
 */

/**
 * @typedef {Object} Page
 * @property {string} id
 * @property {Record<string, string> & { default: string }} paths
 * @property {string[]} langs
 * @property {PageSecurity} [security]
 * @property {{ userGroup: string }[]} [pageUserGroups]
 */

/**
 * @typedef {Object} DesignInfo
 * @property {string} homePageId
 * @property {Page[]} pages
 * @property {Lang[]} langs
 * @property {unknown} [auth]
 * @property {{ href?: string }} [baseTag]
 */

/** @type {Router} */
let router;
/** @type {RouteRecordRaw[]} */
const routes = [];

/** @type {RouterScrollBehavior} */
const scrollBehavior = to => {
    if (to.hash) {
        return {
            el: to.hash,
            behavior: 'smooth',
        };
    } else {
        return { top: 0 };
    }
};

 
/* wwFront:start */
import pluginsSettings from '../../plugins-settings.json';

window.wwg_designInfo = {"id":"f6b22ea0-30ae-464a-b55a-242bcbec0e5c","homePageId":"fce4fe73-5130-4028-8ba0-e6942afe796a","authPluginId":"1fa0dd68-5069-436c-9a7d-3b54c340f1fa","baseTag":{},"defaultTheme":"dark","langs":[{"lang":"en","default":true}],"background":{},"workflows":[],"back":{"isServerSetup":{"staging":false,"production":false}},"auth":null,"pages":[{"id":"61bdfcf2-ada3-4543-bf3f-76bb3b03d71d","linkId":"61bdfcf2-ada3-4543-bf3f-76bb3b03d71d","name":"Edit Supplier","folder":"Clients & Supplier/","paths":{"en":"edit-supplier","default":"edit-supplier"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"c2fe29bf-2948-400e-884a-fa829f872e6e","sectionTitle":"Content","linkId":"8205c2c7-0a7c-4062-b593-5253812a9ea3"},{"uid":"dc0c8b92-457e-4158-834a-8f80b379b270","sectionTitle":"Alert","linkId":"bd26772f-7685-4422-a46b-4a3187a9bd1d"},{"uid":"45c30e31-a4e9-427c-82df-c59affe0c11f","sectionTitle":"Delete","linkId":"dd57743d-1fa3-4e57-8de1-95d07d382889"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"61d91a07-aa56-4fc8-b60f-d4cfc1355faf","linkId":"61d91a07-aa56-4fc8-b60f-d4cfc1355faf","name":"Purchase Order List","folder":"Purchases/","paths":{"en":"supplier-order-list","default":"supplier-order-list"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"3a46f371-d00e-44c5-9b5b-8461af1a81c8","sectionTitle":"Content","linkId":"b00d50f4-60f2-45ce-a727-2e942b7d6799"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"ff4df0de-41ac-4d34-a960-8b19696b308b","linkId":"ff4df0de-41ac-4d34-a960-8b19696b308b","name":"Tickets Admin List","folder":"Tickets/","paths":{"en":"tickets-admin","default":"tickets-admin"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"030f1e1a-2018-4446-aeb1-2e4d0c2c39e0","sectionTitle":"Content","linkId":"98e97427-e719-40f6-a73c-9b04b6bc0b5b"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"6e8d8418-1d66-4fa2-ba55-306061b29e0d","linkId":"6e8d8418-1d66-4fa2-ba55-306061b29e0d","name":"Order List","folder":"Orders/","paths":{"en":"order-list","default":"order-list"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"02beb468-d4ef-4aa6-9b06-f20a440e2b87","sectionTitle":"Content","linkId":"3180a2e5-bfc2-4097-8835-c0ce77c6254c"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"e40ecab2-717e-4694-bcef-f7d5fd602f83","linkId":"e40ecab2-717e-4694-bcef-f7d5fd602f83","name":"Deals","folder":"Dashboard/","paths":{"en":"deals","default":"deals"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"e80f1f91-d525-470c-b3ca-7c749dd74334","sectionTitle":"Content","linkId":"052917a2-acf0-4408-ae8f-1965129adee2"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"307bf241-b2a4-43a6-952a-2b7aa5c2ff88","linkId":"307bf241-b2a4-43a6-952a-2b7aa5c2ff88","name":"Supplier List","folder":"Clients & Supplier/","paths":{"en":"supplier_list","default":"supplier_list"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"b628095a-c26c-4234-84e3-0b5a9189c9c8","sectionTitle":"Content","linkId":"7c664295-e42a-42d2-a4e6-cd23564ee929"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"71f709b9-3c18-47de-9a3f-02dbb37858bd","linkId":"71f709b9-3c18-47de-9a3f-02dbb37858bd","name":"Pending","folder":"Auth/","paths":{"en":"pending","default":"pending"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"fcdb6bf1-b63d-4c97-ab08-49fff23d60af","sectionTitle":"Login","linkId":"688f0556-a9ce-4fd7-92b2-e596b32b687a"}],"pageUserGroups":[],"title":{},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"f76abf58-c3fb-4249-8437-1c4d1d5a3e3e","linkId":"f76abf58-c3fb-4249-8437-1c4d1d5a3e3e","name":"Edit Order","folder":"Orders/","paths":{"en":"edit-order","default":"edit-order"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"b05bc1f5-ad4d-4460-92ca-3582b2828b8f","sectionTitle":"Content","linkId":"9743e6c1-e3cc-446d-bd97-b5c299258228"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"f94ef866-f479-4edf-ac9c-a020dbe956fa","linkId":"f94ef866-f479-4edf-ac9c-a020dbe956fa","name":"Change Email","folder":"Auth/","paths":{"en":"change-email","default":"change-email"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"a599f5ad-d334-4a99-93e3-3e52d61cd28a","sectionTitle":"Login","linkId":"87f9b252-02db-422f-9cc1-803ddadd2692"}],"pageUserGroups":[],"title":{},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"5baa95f0-b3ef-4b1d-a87e-4a4c67f9671a","linkId":"5baa95f0-b3ef-4b1d-a87e-4a4c67f9671a","name":"Edit Purchase Order","folder":"Purchases/","paths":{"en":"edit-purchase-order","default":"edit-purchase-order"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"d65a744e-06e9-44a9-972e-e524479fab1f","sectionTitle":"Content","linkId":"4f0ec758-a4f6-484b-a0fe-032fe4d9ec40"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"76e1c8c3-78dc-4483-90d9-529fad2313a3","linkId":"76e1c8c3-78dc-4483-90d9-529fad2313a3","name":"Edit Goods Receipt","folder":"Purchases/","paths":{"en":"edit-goods-receipt","default":"edit-goods-receipt"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"640cf1e9-f6bd-4ea5-88b9-535ec1dae855","sectionTitle":"Content","linkId":"59e4200b-cabd-43ce-9df7-b23889e72959"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"c28a051a-1044-44b8-96bd-59717123937b","linkId":"c28a051a-1044-44b8-96bd-59717123937b","name":"Sign Up","folder":"Auth/","paths":{"en":"sign-up","default":"sign-up"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8f03308f-e55b-48fe-ba1a-127b3c2e545f","sectionTitle":"Sign up","linkId":"e9a17194-fae8-4e60-80a8-2d6f322b19ea"}],"pageUserGroups":[],"title":{},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"71ffec03-8035-47a2-984d-8b6fd51eeef8","linkId":"71ffec03-8035-47a2-984d-8b6fd51eeef8","name":"Create Quote","folder":"Quotes/","paths":{"en":"create-quote","default":"create-quote"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"b541afc5-2432-4414-840a-71d5b85adc17","sectionTitle":"Content","linkId":"53dbb524-0cef-4554-aa03-8e1769f6781d"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"bed9da16-2792-4970-817a-3daaf70f4b67","linkId":"bed9da16-2792-4970-817a-3daaf70f4b67","name":"View Goods Receipt","folder":"Purchases/","paths":{"en":"view-goods-receipt","default":"view-goods-receipt"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"364527ef-934a-46de-9d5d-604853574a17","sectionTitle":"Content","linkId":"a6c6aeba-e0f4-4393-9b76-1783bcbb1cdc"},{"uid":"c0d4d7c3-74cd-4915-9dd8-0ee13c07316a","sectionTitle":"Print PDF","linkId":"cfd031ff-2b64-413e-a17f-a60efddc26af"},{"uid":"0de29666-7e3f-4ef1-89f5-44176cd11bb4","sectionTitle":"Alert","linkId":"a6c0935a-7ed6-4563-98f8-aaae35dc06a1"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"50fbbd25-5655-4586-ac06-cc36a2fa3fc2","linkId":"50fbbd25-5655-4586-ac06-cc36a2fa3fc2","name":"Product List","folder":"Product/","paths":{"en":"productlist","default":"productlist"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"4fde6bba-605f-4698-8ac6-fdc656a62977","sectionTitle":"Content","linkId":"74cbdade-7844-4c54-9207-095da2af7a59"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"865548c1-3750-4200-ad19-a085ba62937c","linkId":"865548c1-3750-4200-ad19-a085ba62937c","name":"Stripe","folder":"Auth/","paths":{"en":"stripe","default":"stripe"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"50b0de3a-7589-4953-8930-f3e289c9699e","sectionTitle":"Login","linkId":"d5c5ce8e-932c-4760-92bf-cc1772df9b05"}],"pageUserGroups":[],"title":{},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"8e57d4f9-9d40-460b-8ca4-7c5f618fad5d","linkId":"8e57d4f9-9d40-460b-8ca4-7c5f618fad5d","name":"Dashboard","folder":"Dashboard/","paths":{"en":"dashboard","default":"dashboard"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"124f713f-c956-4164-a19a-6a175a5c9232","sectionTitle":"Section","linkId":"a8dc60fe-25df-42f7-90c2-7a9ccabc3469"},{"uid":"ae1caaaa-803b-41e0-836f-a378259976e2","sectionTitle":"Onboarding","linkId":"5a2c993f-5f20-4566-9259-45560aaf7da8"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"9330d6ac-5631-480c-8075-a24545bf0c84","linkId":"9330d6ac-5631-480c-8075-a24545bf0c84","name":"Edit Product","folder":"Product/","paths":{"en":"edit-product","default":"edit-product"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"d9b9c444-aeea-48a5-b9f3-e1d4f5d0863d","sectionTitle":"Content","linkId":"1f5acc03-3c1b-4ee8-91aa-1f06eb3d7393"},{"uid":"b369b64a-b03a-4270-b9ef-00b49dac2e96","sectionTitle":"Alert","linkId":"347c3db0-0f32-4216-bec2-4f81721894a7"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"bef1711d-e7dc-47f7-8438-4e23c9dcb843","linkId":"bef1711d-e7dc-47f7-8438-4e23c9dcb843","name":"Reset Password","folder":"Auth/","paths":{"en":"reset-password","default":"reset-password"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"cc186718-8a68-4a08-a2c5-669249e77f8f","sectionTitle":"Login","linkId":"53becf65-6cc9-490c-9a76-dab8df2b41ad"}],"pageUserGroups":[],"title":{},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"d687cab7-e4cb-428e-a0bd-776ccd28f78a","linkId":"d687cab7-e4cb-428e-a0bd-776ccd28f78a","name":"Success","folder":"Auth/","paths":{"en":"success","default":"success"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"23890b79-0dff-4fa2-adfc-a204af5ffad1","sectionTitle":"Success","linkId":"8e79dff3-c3bb-4db7-a604-afbec8140a67"}],"pageUserGroups":[],"title":{},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"73531853-cd4b-4d5a-9b70-286cc83c530e","linkId":"73531853-cd4b-4d5a-9b70-286cc83c530e","name":"Customer List","folder":"Clients & Supplier/","paths":{"en":"customer-list","default":"customer-list"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"cc9058dc-db04-4b1a-932f-a46f21c18428","sectionTitle":"Content","linkId":"21f29afb-484a-4fb1-9fce-7368ca313326"}],"pageUserGroups":[{},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"855c5711-15b2-4ad1-8727-c6eeb7cc4a81","linkId":"855c5711-15b2-4ad1-8727-c6eeb7cc4a81","name":"Edit Client","folder":"Clients & Supplier/","paths":{"en":"edit-client","default":"edit-client"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"dd7e653a-44ef-41cf-ab06-ee346311e592","sectionTitle":"Content","linkId":"3f2af688-2d7d-4e38-80b3-2c92834b45ea"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"02bdd0ed-c665-4252-ad0f-fd4a74ced13c","linkId":"02bdd0ed-c665-4252-ad0f-fd4a74ced13c","name":"Client List","folder":"Clients & Supplier/","paths":{"en":"client_list","default":"client_list"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"956e86e7-47d1-49f8-8f7e-bbc59141d392","sectionTitle":"Alert","linkId":"c2e9ce13-98e3-44d3-97db-22e0a997261d"},{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"7220f036-acd3-4faa-b0e9-bdc8906bb6d4","sectionTitle":"Content","linkId":"5c288aa7-ca00-4c59-abd5-7fdea9df00ab"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"64ad4b22-1707-4b75-9e09-66eddcae2c62","linkId":"64ad4b22-1707-4b75-9e09-66eddcae2c62","name":"Cancel","folder":"Auth/","paths":{"en":"cancel","default":"cancel"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"839ae18d-0a1b-4666-a148-86056cca763d","sectionTitle":"Login","linkId":"37e9a5ac-6e98-4b58-9648-478792062045"}],"pageUserGroups":[],"title":{},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"50228c54-cb5c-49b1-8588-fd372ddbf0bb","linkId":"50228c54-cb5c-49b1-8588-fd372ddbf0bb","name":"Reports","folder":"Dashboard/","paths":{"en":"reports","default":"reports"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"4e3923a4-8ac8-4770-aa44-0b43297f9a78","sectionTitle":"Content","linkId":"bb9bfd1d-c217-44f1-bd90-003e1f04fd1c"},{"uid":"d932043b-1137-4a02-943a-1532fa86ff88","sectionTitle":"Alert","linkId":"c2e7a27c-9cef-4a93-9a10-7cba1365029d"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"9e5d43eb-f3dd-4a86-a258-5431e8d5de30","linkId":"9e5d43eb-f3dd-4a86-a258-5431e8d5de30","name":"Dashboard Admin","folder":"Dashboard/","paths":{"en":"dashboard-admin","default":"dashboard-admin"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"2bb31b45-b7f1-44aa-8da8-b53b03c88b7f","sectionTitle":"Content","linkId":"e8fdbd7f-6f62-497a-9cbf-5872e21e870c"},{"uid":"ff0bd3d3-43e7-42b3-8894-adcf87456dee","sectionTitle":"Alert","linkId":"f404e79d-f595-41f2-8468-a64b75ec0b27"}],"pageUserGroups":[{},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"b23f0f77-adad-4875-b401-7427b7945b70","linkId":"b23f0f77-adad-4875-b401-7427b7945b70","name":"Time Tracking","folder":"Dashboard/","paths":{"en":"timetracking","default":"timetracking"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"ea05e05b-047d-4cb6-99e0-e2864b9469d7","sectionTitle":"Content","linkId":"2e04bb51-c6eb-40a7-8646-d0c49e0a60b9"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"9eb79191-cb13-4273-a436-c8992a6842c5","linkId":"9eb79191-cb13-4273-a436-c8992a6842c5","name":"Client Details","folder":"Clients & Supplier/","paths":{"en":"client_details","default":"client_details"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"eebc4d83-0530-481d-9a5d-28de20486093","sectionTitle":"Content","linkId":"34022040-874e-4924-8ce4-3b1ac30f8093"},{"uid":"192aa842-8ed3-42a1-9a96-ccfcd7fca295","sectionTitle":"Alert","linkId":"780d920f-a2e0-4012-82e9-b7acea6b5245"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"3d9a9e8f-cd20-407d-9431-1d8de56d446b","linkId":"3d9a9e8f-cd20-407d-9431-1d8de56d446b","name":"Edit Quote","folder":"Quotes/","paths":{"en":"edit-quote","default":"edit-quote"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"dc81b543-f6f6-45c8-92ca-f38af485ad62","sectionTitle":"Content","linkId":"1c162263-2c72-46d2-807c-ec91c2e65b4d"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"1bf11d31-0b8a-49e7-a674-dfb0244fa142","linkId":"1bf11d31-0b8a-49e7-a674-dfb0244fa142","name":"Unsubscribe","folder":"Quotes/","paths":{"en":"unsubscribe/{{id|7}}","default":"unsubscribe/{{id|7}}"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"3830bd48-f2bc-4ed0-8c81-1acf176dd1e3","sectionTitle":"Success","linkId":"0be5d9d5-b68d-4d16-a492-023dea2f1ecb"}],"pageUserGroups":[],"title":{},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"a4c642bb-ec58-48cf-92a2-b64479620bc1","linkId":"a4c642bb-ec58-48cf-92a2-b64479620bc1","name":"Calendar","folder":"Dashboard/","paths":{"en":"calendar","default":"calendar"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"98626aa2-356e-40bc-8651-1f954bbac804","sectionTitle":"Content","linkId":"abd5354f-058f-40e0-bc8e-2eca52e2598c"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"041208b8-aed2-4c7f-99e8-69098987ce3a","linkId":"041208b8-aed2-4c7f-99e8-69098987ce3a","name":"Invoice","folder":"Quotes/","paths":{"en":"invoice/{{shareableid|BIVgIkGXzHheYFfKcriMrPbp}}","default":"invoice/{{shareableid|BIVgIkGXzHheYFfKcriMrPbp}}"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"c3ffa34f-a60b-4953-a608-9a032393cf61","sectionTitle":"Content","linkId":"0f388591-8144-4db5-bdae-66e0ca896708"},{"uid":"362fc0a9-dd21-40f2-b403-c1b8332c9c0f","sectionTitle":"Loader","linkId":"d8d7db75-2450-407d-a430-e797e8495e5a"}],"pageUserGroups":[],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"275bd01c-c504-442d-9d7d-b0de8bb3abc7","linkId":"275bd01c-c504-442d-9d7d-b0de8bb3abc7","name":"Edit Invoice","folder":"Invoices/","paths":{"en":"edit-invoice","default":"edit-invoice"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"655f9180-9e40-46df-9e8f-fd5d0624a51e","sectionTitle":"Content","linkId":"84d4edc6-e2ad-488c-b35c-b2b0046d2abf"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"81a8b3dc-12d8-4b34-befe-2e0854693884","linkId":"81a8b3dc-12d8-4b34-befe-2e0854693884","name":"Create Purchase Order","folder":"Purchases/","paths":{"en":"create-supplier-order","default":"create-supplier-order"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"b10cb4ee-5a6f-416b-812b-bedee0b7a2fd","sectionTitle":"Content","linkId":"79190bd3-6ca1-47eb-bdc0-971919ba8553"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"f116313c-674e-4213-9531-ef019f7aee62","linkId":"f116313c-674e-4213-9531-ef019f7aee62","name":"Create Product","folder":"Product/","paths":{"en":"create-product","default":"create-product"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"89d48dc0-384c-4c67-b318-08f7e917d309","sectionTitle":"Content","linkId":"ba9e4618-f7a0-4b9d-82f0-26f00d55fa99"},{"uid":"86e3e7ca-324e-4534-a543-18227711a79c","sectionTitle":"Alert","linkId":"1b055e16-eb82-409c-bbfb-c699a8a149d0"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"d902a7dc-6331-485b-abde-3fe6241e99d9","linkId":"d902a7dc-6331-485b-abde-3fe6241e99d9","name":"Change Password","folder":"Auth/","paths":{"en":"change-password","default":"change-password"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"7e20f473-c6c9-4618-9853-031f36e0deee","sectionTitle":"Login","linkId":"f496f174-1e02-4325-a3ad-9ff920ea7360"}],"pageUserGroups":[],"title":{},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"78bd86b6-d24c-460e-86df-bf483284fdb0","linkId":"78bd86b6-d24c-460e-86df-bf483284fdb0","name":"Create Order","folder":"Orders/","paths":{"en":"create-order","default":"create-order"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"f8030d3c-b9c7-4834-9f49-415a589a606c","sectionTitle":"Content","linkId":"48a8e9ac-33ad-43f6-9c15-2fb4668d37b8"},{"uid":"62ab45d7-6430-4ce4-b686-8cd4c7f0518c","sectionTitle":"Alert","linkId":"fe091883-372d-45f7-adbf-d8bf0b9fa484"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"b4b4d5a0-5a4e-4aa1-a6e5-2237fb00950a","linkId":"b4b4d5a0-5a4e-4aa1-a6e5-2237fb00950a","name":"View Purchase Order","folder":"Purchases/","paths":{"en":"view-purchase-order","default":"view-purchase-order"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"16ec4fd4-161b-4e0d-9067-c3476d898f99","sectionTitle":"Content","linkId":"afa7c4ea-3e57-4be4-bc23-d966150b9789"},{"uid":"9f03ba0b-11ee-4843-940c-0f85cd955f93","sectionTitle":"Print PDF","linkId":"94a66887-fa37-4497-b1c8-080a0240e4e1"},{"uid":"4d48769b-6c04-4530-a1f8-2d7d386d6939","sectionTitle":"Alert","linkId":"bce9f92f-a32e-40ba-814b-d555d259bedd"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"068535fb-561d-4e8d-b12a-2567c9b6e666","linkId":"068535fb-561d-4e8d-b12a-2567c9b6e666","name":"Create Goods Receipt","folder":"Purchases/","paths":{"en":"goods-receipt","default":"goods-receipt"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"224e92c0-2583-4b12-9394-499ecbddb23a","sectionTitle":"Content","linkId":"0229ec7f-585d-469d-b1e4-33794795baea"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"748060a6-69f4-4808-850e-41e860f05316","linkId":"748060a6-69f4-4808-850e-41e860f05316","name":"Booking Success","folder":"Auth/","paths":{"en":"booking-success","default":"booking-success"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"d1991f28-6ccc-4ffa-8ea9-67b4408a6c0f","sectionTitle":"Success","linkId":"38a1b7e6-923d-4449-8f7f-e9f5940d1d7d"}],"pageUserGroups":[],"title":{},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"886ca460-5526-4dc7-b542-ff533d59ddea","linkId":"886ca460-5526-4dc7-b542-ff533d59ddea","name":"Quote List","folder":"Quotes/","paths":{"en":"quote-list","default":"quote-list"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"4f48bac5-ec6a-4d92-ad8d-4db8d748eb91","sectionTitle":"Content","linkId":"c735a30d-3626-4fbe-a2e7-853dcb6546ce"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"75dfd22a-6e59-4f60-ab94-8b92932fb3bc","linkId":"75dfd22a-6e59-4f60-ab94-8b92932fb3bc","name":"Edit Ticket","folder":"Tickets/","paths":{"en":"edit-ticket","default":"edit-ticket"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"e8bb325f-8961-48bc-a59a-c96f15d12e09","sectionTitle":"Content","linkId":"6d946c43-9b69-4d0c-988a-11e3d9b434c1"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"48434fba-ea8f-4e0f-bc39-466811870b86","linkId":"48434fba-ea8f-4e0f-bc39-466811870b86","name":"Create Invoice","folder":"Invoices/","paths":{"en":"create-invoice","default":"create-invoice"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"5c00ddcf-2218-4dde-9ee4-4004e4e1937a","sectionTitle":"Content","linkId":"c9902a2a-11bb-4483-80b3-53d1e5312132"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"ab255a99-b1f2-4c75-bf1c-ae5d635c84e4","linkId":"ab255a99-b1f2-4c75-bf1c-ae5d635c84e4","name":"Rejected","folder":"Auth/","paths":{"en":"rejected","default":"rejected"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"c5d5d34f-7510-464b-8a8d-18f6d7a5b7a9","sectionTitle":"Success","linkId":"77036853-f69f-49e5-8277-4c9623bbc056"}],"pageUserGroups":[],"title":{},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"b5d77ae6-a378-4538-b13e-5cf6c38b3df7","linkId":"b5d77ae6-a378-4538-b13e-5cf6c38b3df7","name":"Create Ticket","folder":"Tickets/","paths":{"en":"create-ticket","default":"create-ticket"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"47692d25-840a-46af-be11-fca9a4433e65","sectionTitle":"Content","linkId":"120a125a-9ef2-4c98-b5cf-d02b5a1f574c"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"a5106a74-85e8-4fb5-9140-b930a67b05e0","linkId":"a5106a74-85e8-4fb5-9140-b930a67b05e0","name":"Tasks","folder":"Dashboard/","paths":{"en":"tasks","default":"tasks"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"649ec814-1119-453a-8e00-19d7e4a23b9d","sectionTitle":"Content","linkId":"e4447a52-f9c7-47cc-b4c3-1dca278b1294"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"c6481d79-497e-411a-a4c2-30d80d51bcaa","linkId":"c6481d79-497e-411a-a4c2-30d80d51bcaa","name":"Settings","folder":"Dashboard/","paths":{"en":"settings","default":"settings"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"eaed6c1f-e434-41f7-8ce1-ab52d492a7d1","sectionTitle":"Content","linkId":"941c1f00-10a7-4169-8ec4-0b5ba945088a"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"71a13de9-59c1-4c70-96de-3a33ffabce12","linkId":"71a13de9-59c1-4c70-96de-3a33ffabce12","name":"Invoice List","folder":"Invoices/","paths":{"en":"invoice-list","default":"invoice-list"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"749abe2f-6800-4992-bf67-bead1920a3ca","sectionTitle":"Content","linkId":"630e61a8-27c9-4e27-8ccc-499626c7c3c7"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"9c37c382-5103-406e-8574-148493b2c12d","linkId":"9c37c382-5103-406e-8574-148493b2c12d","name":"Contact List","folder":"Clients & Supplier/","paths":{"en":"contact_list","default":"contact_list"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"76425d46-01dd-47e0-9e90-5aac5d5e225c","sectionTitle":"Content","linkId":"c91ac2db-5e2e-41aa-a925-bbe3a69e042d"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"16253f87-d33c-46cd-b1fc-54917a573979","linkId":"16253f87-d33c-46cd-b1fc-54917a573979","name":"Hourly Rate Calculator","folder":"Dashboard/","paths":{"en":"hourly-rate-calculator","default":"hourly-rate-calculator"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"fa6e0e9e-0023-4196-a920-e67f361349cd","sectionTitle":"Content","linkId":"26249acf-b5db-4ea0-ae09-25a1b93e72f1"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"bd3bd814-9396-42ca-80df-258ad6b53612","linkId":"bd3bd814-9396-42ca-80df-258ad6b53612","name":"Goods Receipt List","folder":"Purchases/","paths":{"en":"goods-receipt-list","default":"goods-receipt-list"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"fc47bb4f-22aa-442b-a8f2-65e93c05512e","sectionTitle":"Content","linkId":"8a0f1ef7-6968-49b1-83f6-4805e16afa66"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"98cab6c8-539a-4b85-b304-57091a02ffe3","linkId":"98cab6c8-539a-4b85-b304-57091a02ffe3","name":"Tickets List","folder":"Tickets/","paths":{"en":"tickets","default":"tickets"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"134579d6-0084-47c6-ac57-c9340f6fc3b2","sectionTitle":"Content","linkId":"8a4e5522-100a-4c06-a847-9c67ee16b9c8"},{"uid":"e3e20ab5-a4fa-4e98-a71b-b2f899658931","sectionTitle":"Alert","linkId":"29429e20-9abf-47d4-94f3-b40f4d9a0bd5"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"fce4fe73-5130-4028-8ba0-e6942afe796a","linkId":"fce4fe73-5130-4028-8ba0-e6942afe796a","name":"Log In","folder":"Auth/","paths":{"en":"log-in","default":"log-in"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"4ade29ea-af68-404a-8862-406076b46bd1","sectionTitle":"Login","linkId":"25122edb-1b83-4c62-8bb4-d236768f1aa1"},{"uid":"a2077bd3-6fc1-4fcc-9c92-f4bfc6491fb7","sectionTitle":"Loader","linkId":"f66e7268-0b96-47b3-96c2-2a9e133b424d"}],"pageUserGroups":[],"title":{"en":"Nextpulse CRM"},"meta":{"desc":{"en":"Innovative CRM/ERP solutions,\ncrafted for solopreneurs and small businesses."},"keywords":{"en":"ERP, CRM"},"socialDesc":{},"socialTitle":{"en":"Nextpulse CRM"},"structuredData":{}},"metaImage":"","security":{}},{"id":"2a1b4cac-c36e-4985-99e3-9484b92a49d8","linkId":"2a1b4cac-c36e-4985-99e3-9484b92a49d8","name":"Graph View","folder":null,"paths":{"en":"graph-view","default":"graph-view"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"2aedb5ad-3993-4512-a0f2-3019754eeee5","sectionTitle":"Content","linkId":"41f6a5f8-9ad4-433a-a65e-6fcdc62b79ec"}],"pageUserGroups":[],"title":{},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"6d636320-358a-4643-ba38-a75ad40d3c4a","linkId":"6d636320-358a-4643-ba38-a75ad40d3c4a","name":"Expenses","folder":"Clients & Supplier/","paths":{"en":"expenses","default":"expenses"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"150d0408-d2fe-4d64-8152-d837f0ce4974","sectionTitle":"Alert","linkId":"6fc4e3c5-eda1-42da-91d4-dec8999b231b"},{"uid":"8a1c9209-55b1-4f0b-b490-6bfcf5cec024","sectionTitle":"Sidemenu","linkId":"76af2b4e-f706-4d01-8618-adbe9954d301"},{"uid":"82cb9353-643f-4fad-a531-712ba9967717","sectionTitle":"Content","linkId":"0385ac65-5d2b-42aa-accd-562079302abf"},{"uid":"c909b2fa-1cf4-427b-91aa-4318d9379ffe","sectionTitle":"Alert","linkId":"99c64e84-ff27-4350-baec-f37b7b9dfaf5"}],"pageUserGroups":[{},{"userGroup":{"id":"e94675f8-680a-40cc-bf96-c3641e94164f","roles":[{"value":"1fa02e94-22a9-437e-8cf2-dd343957c4fc"}]}},{"userGroup":{"id":"82ea7b5c-24fb-4775-802b-4920597f4af7","roles":[{"value":"efca53e0-e3c9-4af5-a147-4749f86c5bed"}]}}],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"c8516bde-2dad-4d43-88f7-0b9d0963cb99","linkId":"c8516bde-2dad-4d43-88f7-0b9d0963cb99","name":"Booking","folder":"Dashboard/","paths":{"en":"booking/{{userid|5ff0b73b-8ffc-462a-a344-7e334e352d3f}}","default":"booking/{{userid|5ff0b73b-8ffc-462a-a344-7e334e352d3f}}"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"c99f6d70-18b2-480e-9756-5437552ae1c9","sectionTitle":"Content","linkId":"6418c3e1-6e7b-4b27-90e8-968691559322"},{"uid":"6fce0631-97cd-434f-a594-bedb1f9efbe4","sectionTitle":"Alert","linkId":"98a21621-e2ec-451f-b238-87923f24043c"}],"pageUserGroups":[],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}},{"id":"7e49469f-4b6e-44d8-9691-e47f784d5167","linkId":"7e49469f-4b6e-44d8-9691-e47f784d5167","name":"Quote","folder":"Quotes/","paths":{"en":"quote/{{shareableid|SzGgIEHqjnPjxOhyLZRbOGjL}}","default":"quote/{{shareableid|SzGgIEHqjnPjxOhyLZRbOGjL}}"},"langs":["en"],"cmsDataSetPath":null,"sections":[{"uid":"29cb154f-23c6-4306-a780-dd94f80d236b","sectionTitle":"Content","linkId":"4b8b7610-5135-41a3-a6a6-63b93a7e3e75"},{"uid":"f8eae4f8-105e-4c39-83ad-fce2a0dfed0d","sectionTitle":"Loader","linkId":"4e77ca5f-572c-4971-a7a8-03c7d3d0efbb"}],"pageUserGroups":[],"title":{"en":"","fr":"Vide | Commencer à partir de zéro"},"meta":{"desc":{},"keywords":{},"socialDesc":{},"socialTitle":{},"structuredData":{}},"metaImage":"","security":{}}],"plugins":[{"id":"00d22f72-1a03-44f8-ad68-c593dc80b543","name":"Stripe","namespace":"stripe"},{"id":"f9ef41c3-1c53-4857-855b-f2f6a40b7186","name":"Supabase","namespace":"supabase"},{"id":"1fa0dd68-5069-436c-9a7d-3b54c340f1fa","name":"Supabase Auth","namespace":"supabaseAuth"},{"id":"1c5f5c0f-5609-4031-9e57-5bb4811be7b3","name":"Youtube","namespace":"youtube"},{"id":"ee24f5ac-e15e-4ddd-baa4-0b4baedf90c9","name":"CSV","namespace":"csv"},{"id":"9c40819b-4a8f-468f-9ba5-4b9699f3361f","name":"Charts","namespace":"chartjs"},{"id":"832d6f7a-42c3-43f1-a3ce-9a678272f811","name":"Date","namespace":"dayjs"},{"id":"2bd1c688-31c5-443e-ae25-59aa5b6431fb","name":"REST API","namespace":"restApi"},{"id":"d66a250d-8468-469e-ad33-ee028f632398","name":"OpenAI","namespace":"openai"}]};
window.wwg_cacheVersion = 1263;
window.wwg_pluginsSettings = pluginsSettings;
window.wwg_disableManifest = false;

/** @type {Lang} */
const defaultLang = window.wwg_designInfo.langs.find(({ default: isDefault }) => isDefault) || {
    lang: 'en',
    default: true,
};
const isServerRendering = import.meta.env.SSR;

/**
 * @param {Page} page
 * @param {Lang} lang
 * @param {string} [forcedPath]
 */
const registerRoute = (page, lang, forcedPath) => {
    const langSlug = !lang.default || lang.isDefaultPath ? `/${lang.lang}` : '';
    let path =
        forcedPath ||
        (page.id === window.wwg_designInfo.homePageId ? '/' : `/${page.paths[lang.lang] || page.paths.default}`);

    path = convertPathToRouterFormat(path);

    routes.push({
        path: langSlug + path,
        component: wwPage,
        name: `page-${page.id}-${lang.lang}`,
        meta: {
            pageId: page.id,
            lang,
            isPrivate: !!page.pageUserGroups?.length,
        },
        async beforeEnter(to, from) {
            if (to.name === from.name) return;
            //Set page lang
            wwLib.wwLang.defaultLang = defaultLang.lang;
            wwLib.$store.dispatch('front/setLang', lang.lang);

            if (!isStaticRenderingActive()) {
                const canContinue = await initializePageRuntime(page, to);
                if (!canContinue) return null;
            }

            try {
                const { default: registerPageComponents } = await import(`@/pages/${page.id.split('_')[0]}.js`);
                await registerPageComponents(window.vm);
                await wwLib.wwWebsiteData.fetchPage(page.id);

                //Scroll to section or on top after page change
                if (isStaticRenderingActive()) {
                    return;
                } else if (to.hash) {
                    const targetElement = document.getElementById(to.hash.replace('#', ''));
                    if (targetElement) targetElement.scrollIntoView();
                } else {
                    document.body.scrollTop = document.documentElement.scrollTop = 0;
                }

                return;
            } catch (err) {
                wwLib.$store.dispatch('front/showPageLoadProgress', false);
                if (isStaticRenderingActive()) throw err;

                if (err.redirectUrl) {
                    return { path: err.redirectUrl || '404' };
                } else {
                    //Any other error: go to target page using window.location
                    window.location = to.fullPath;
                }
            }
        },
    });
};

for (const page of window.wwg_designInfo.pages) {
    for (const lang of window.wwg_designInfo.langs) {
        if (!page.langs.includes(lang.lang)) continue;
        registerRoute(page, lang);
    }
}

const page404 = window.wwg_designInfo.pages.find(page => page.paths.default === '404');
if (page404) {
    for (const lang of window.wwg_designInfo.langs) {
        // Create routes /:lang/:pathMatch(.*)* etc for all langs of the 404 page
        if (!page404.langs.includes(lang.lang)) continue;
        registerRoute(
            page404,
            {
                default: false,
                lang: lang.lang,
            },
            '/:pathMatch(.*)*'
        );
    }
    // Create route /:pathMatch(.*)* using default project lang
    registerRoute(page404, { default: true, isDefaultPath: false, lang: defaultLang.lang }, '/:pathMatch(.*)*');
} else {
    routes.push({
        path: '/:pathMatch(.*)*',
        redirect: null,
        async beforeEnter() {
            window.location.href = '/404';
        },
    });
}

const isProd = getRuntimeEnvironment() === 'production';

async function initializePageRuntime(page, route) {
    const backAuthStore = useBackAuthStore(wwLib.$pinia);
    if (!wwLib.wwAuth.plugin && !backAuthStore.projectAuth && window.wwg_designInfo.auth) {
        backAuthStore.setProjectAuth(window.wwg_designInfo.auth);
    }

    await initializePlugins();
    await initializeIntegrationInstances();

    if (!wwLib.wwAuth.plugin) {
        await backAuthStore.refresh();
        const projectAuth = backAuthStore.projectAuth || {};

        if (page.security?.accessRule !== 'authenticated') return true;
        if (!backAuthStore.isAuthenticated) {
            window.location.href = `${wwLib.wwPageHelper.getPagePath(
                projectAuth.unauthenticatedPageId
            )}?_source=${route.path}`;
            return false;
        }
        if (!page.security.accessRoles?.length) return true;

        const hasAccess =
            page.security.accessRolesCondition === 'AND'
                ? backAuthStore.matchAllRoles(page.security.accessRoles)
                : backAuthStore.matchAnyRoles(page.security.accessRoles);
        if (hasAccess) return true;

        window.location.href = `${wwLib.wwPageHelper.getPagePath(
            projectAuth.unauthorizedPageId
        )}?_source=${route.path}`;
        return false;
    }

    if (!page.pageUserGroups?.length) return true;
    await wwLib.wwAuth.init();

    if (!wwLib.wwAuth.getIsAuthenticated()) {
        window.location.href = `${wwLib.wwPageHelper.getPagePath(
            wwLib.wwAuth.getUnauthenticatedPageId()
        )}?_source=${route.path}`;
        return false;
    }

    if (
        page.pageUserGroups.length > 1 &&
        !wwLib.wwAuth.matchUserGroups(page.pageUserGroups.map(({ userGroup }) => userGroup))
    ) {
        window.location.href = `${wwLib.wwPageHelper.getPagePath(
            wwLib.wwAuth.getUnauthorizedPageId()
        )}?_source=${route.path}`;
        return false;
    }

    return true;
}

/**
 * Initializes the current route's traditional runtime dependencies after Vue has
 * hydrated the static projection. Static rendering remains active until this resolves,
 * so client islands and dynamic bindings cannot run against a partial runtime.
 */
export async function initializeCurrentRouteRuntime() {
    const route = router.currentRoute.value;
    const page = window.wwg_designInfo.pages.find(candidate => candidate.id === route.meta.pageId);
    if (!page) throw new Error(`Unable to initialize runtime for route ${route.fullPath}: page is unavailable.`);

    const canContinue = await initializePageRuntime(page, route);
    if (!canContinue) return { status: 'redirected' };
    return { status: 'ready', route };
}

/**
 * Starts the data phase without delaying the mounted lifecycle, matching normal
 * navigation where collections and workflows may initialize after the first render.
 */
export function startCurrentRouteDataInitialization(route) {
    return initializeData(route);
}

function createFrontHistory(serverRendering) {
    if (serverRendering) return createMemoryHistory();

    if (isProd && window.wwg_designInfo.baseTag?.href) {
        let baseTag = window.wwg_designInfo.baseTag.href;
        if (!baseTag.startsWith('/')) {
            baseTag = '/' + baseTag;
        }
        if (!baseTag.endsWith('/')) {
            baseTag += '/';
        }
        return createWebHistory(baseTag);
    }

    return createWebHistory();
}

export function createFrontRouter({ serverRendering = false } = {}) {
    const frontRouter = createRouter({
        history: createFrontHistory(serverRendering),
        routes,
        scrollBehavior,
    });

    //Trigger on page unload
    let isFirstNavigation = true;
    frontRouter.beforeEach(async (to, from) => {
        if (to.name === from.name) return;
        if (!isFirstNavigation && !serverRendering) await onPageUnload();
        isFirstNavigation = false;
        wwLib.globalVariables._navigationId++;
        return;
    });

    //Init page
    frontRouter.afterEach((to, from, failure) => {
        wwLib.$store.dispatch('front/showPageLoadProgress', false);
        let fromPath = from.path;
        let toPath = to.path;
        if (!fromPath.endsWith('/')) fromPath = fromPath + '/';
        if (!toPath.endsWith('/')) toPath = toPath + '/';
        if (failure || (from.name && toPath === fromPath) || serverRendering || isStaticRenderingActive()) return;
        void initializeData(to);
    });

    return frontRouter;
}

router = createFrontRouter({ serverRendering: isServerRendering });
/* wwFront:end */

export default router;
